import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import javafx.scene.control.TextField;
import javafx.stage.Stage;

class MyTest extends JavaFXTemplate {

	@Test
	void test() {
		Stage primaryStage = new Stage();
		try {
			start(primaryStage);  // creates Application with Menu 
		} catch (Exception e) {     
			e.printStackTrace();
		}
		
	}
	@Test
	void test2() {
		Stage primaryStage = new Stage();
		try {
			setfirstscreen(primaryStage);  // creates Application with menu directly
		} catch (Exception e) {     
			e.printStackTrace();
		}
		
	}
	
	@Test
	void test3() {
		Stage primaryStage = new Stage();
		int spots  = 3;
		try {
			thirdscreen(primaryStage,spots);  // creates Application with mentioned spots and grid to select spots 
		} catch (Exception e) {     
			e.printStackTrace();
		}
		
	}
	
	
	
	

}
