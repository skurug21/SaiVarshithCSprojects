package com.example.javafxtemplate;

import javafx.scene.control.*;
import javafx.scene.image.Image;
//import javafx.scene.control.Button;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;

import javafx.collections.ObservableList;
import javafx.collections.FXCollections;

import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventTarget;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

import java.time.LocalDate;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.beans.binding.Bindings;

import java.net.URL;

public class HelloApplication extends Application {
    public static PauseTransition p1 = new PauseTransition(Duration.seconds(1));  // for pause transiiton
    public static VBox v ; // vbox for fscreen which is used to show lottery selected numbers
    static String name1 ;
    static LocalDate dob ;
    static String email;
    static String no;

    static String imgADR = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7MmfKPT_pzXXmBiGFXRDoFnYUgpFBmTo28A&usqp=CAU";

    static int months;
    static int checkmonths;

    static char themeSelector ;
    static Map<String,Map<String,String>> monthdetails = new HashMap< String,Map<String,String>>();


    //-------------------------------------------------------------------------------------------------------------
    public static void main(String[] args) {
        launch(args);
    }


    static void newuser (Stage firststage) {
        Button personaldetails = new Button("Add Personal Details");
        Button financialdetails = new Button("Add Financial Details");
        Button Viewstats = new Button("View Stats");
        Viewstats.setDisable(true);
        VBox v1 = new VBox (50,personaldetails,financialdetails,Viewstats);

        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        personaldetails.setOnAction(e -> {
            try {

                Pdetailscreen(firststage,false,false);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        financialdetails.setOnAction(e -> {
            try {

                Fdetailsoptions(firststage,false,false);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();
    }

    static void Fdetailsoptions(Stage firststage,boolean pdetails,boolean fdetails)
    {






        Text text = new Text();


        text.setText("Select the number of months to fill in financial details");

        ObservableList<String> options =
                FXCollections.observableArrayList(
                        "1",
                        "2",
                        "6"
                );

        final ComboBox comboBox = new ComboBox(options);
        Button confirm = new Button("Confirm");

        confirm.setOnAction(e -> {
            try {
                System.out.println("ssssssssss");
                String check  = (String) comboBox.getValue();
                months = Integer.parseInt(check);
                System.out.println(check);
                //months = check;
                financialDetailsScreen(firststage,pdetails,fdetails,months,1);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });



        VBox v1 =  new VBox(25,text, comboBox,confirm);
        v1.setAlignment(Pos.TOP_LEFT);
        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        v1.setAlignment(Pos.TOP_CENTER);
        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();
    }




    static void Pdetailscreen(Stage firststage,boolean pdetails,boolean fdetails)
    {


        Label name = new Label("Name :");
        name. setFont(new Font("Arial", 10));
        TextField entername ;

        Label DOB = new Label("Date of Birth :");
        name. setFont(new Font("Arial", 10));
        DatePicker d = new DatePicker();
        ;

        Label Email = new Label("Email :");
        name. setFont(new Font("Arial", 10));
        TextField enterEmail ;



        Label phoneno = new Label("Date of ph.no :");
        name. setFont(new Font("Arial", 10));
        TextField enterphno ;

        if (pdetails == false) {
            entername = new TextField("Enter your name here");
            enterEmail = new TextField("Enter your Email here");
            enterphno = new TextField("Enter your ph.no here");

        }
        else {
            enterEmail = new TextField(email);
            enterphno = new TextField(no);
            entername = new TextField(name1);
        }
        HBox h1 = new HBox(2,name,entername);
        HBox h2 = new HBox(2,DOB,d);
        HBox h3 = new HBox(2,Email,enterEmail);
        HBox h4 = new HBox(2,phoneno,enterphno);
        Button confirm = new Button("Confirm and Back");



        confirm.setOnAction(e -> {
            try {
                String names = entername.getText();
                LocalDate dob = d.getValue();
                String em = enterEmail.getText();
                String no = enterphno.getText();
                AfterPdetailscreen(firststage,names,no,em,dob,true,fdetails);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        VBox v1 =  new VBox(25,h1,h2,h3,h4,confirm);
        v1.setAlignment(Pos.TOP_LEFT);
        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();
    }

//-------------------------------------------------------------------------------------------------------------

    static void financialDetailsScreen(Stage firstStage,boolean pdetails,boolean fdetails,int months, int checkmonth){



        Label bank = new Label("Bank :");
        bank.setFont(new Font("Arial", 10));
        TextField enterBank ;
        if (fdetails == true ) {
            enterBank = new TextField("banks");
        }
        else {
            enterBank = new TextField("Enter your bank here");

        }

        Text month  = new Text("Personalize month name (optional)");
        month.setFont(new Font("Arial", 10));
        TextField whichmonth = new TextField("Month " + checkmonth );



        Text spending  = new Text("Past Month Spending Total :");
        spending.setFont(new Font("Arial", 10));
        TextField spendinginfo = new TextField("0");



        Text food  = new Text("Past Month Spending Total Food :");
        food.setFont(new Font("Arial", 10));
        TextField foodinfo = new TextField("0");

        Text travel  = new Text("Past Month Spending Travel Total :");
        travel.setFont(new Font("Arial", 10));
        TextField travelinfo = new TextField("0");



        Text utilities  = new Text("Past Month Total Spending on Utilities :");
        utilities.setFont(new Font("Arial", 10));
        TextField utilitiesinfo = new TextField("0");


        Text rent  = new Text("Past Month Total Spending on Rent :");
        rent.setFont(new Font("Arial", 10));
        TextField rentinfo = new TextField("0");



        Text miscellaneous  = new Text ("Past Month total spending on Miscellaneous total :");
        miscellaneous.setFont(new Font("Arial", 10));
        TextField miscellaneousinfo = new TextField("0");

        HBox h0 = new HBox(2,month,whichmonth);
        HBox h1 = new HBox(2,bank,enterBank);
        HBox h2 = new HBox(2,spending,spendinginfo);
        HBox h3 = new HBox(2,food,foodinfo);
        HBox h4 = new HBox(2,travel,travelinfo);
        HBox h5 = new HBox(2,utilities,utilitiesinfo);
        HBox h6 = new HBox(2,rent,rentinfo);
        HBox h7 = new HBox(2,miscellaneous,miscellaneousinfo);
        Button confirm ;
        if ( checkmonth < months) {

            confirm = new Button("Confirm & Next Month");
            confirm.setOnAction(e -> {
                try {
                    String banks = enterBank.getText();

                    String pastmonth1 = spendinginfo.getText();


                    String food1 = foodinfo.getText();


                    String travel1 = travelinfo.getText();


                    String utilities1 = utilitiesinfo.getText();


                    String rent1 = rentinfo.getText();

                    String misc1 = miscellaneousinfo.getText();


                    String miscellaneous1 = miscellaneousinfo.getText();
                    Map<String, String> month_ = new HashMap<String, String>();
                    month_.put("banks",banks);
                    month_.put("Total",pastmonth1);
                    month_.put("Food",food1);
                    month_.put("Travel",travel1);
                    month_.put("Utilities",utilities1);
                    month_.put("Rent",rent1);
                    month_.put("Misc",misc1);

                    String monthname  = whichmonth.getText();

                    monthdetails.put( monthname,month_);

                    financialDetailsScreen(firstStage,pdetails,fdetails,months,checkmonth+1);

                    for (Map.Entry<String,String> entry : month_.entrySet())
                        System.out.println("Key = " + entry.getKey() +
                                ", Value = " + entry.getValue());

                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            });
        }
        else {
            confirm = new Button("Confirm (All months filled)");


            confirm.setOnAction(e -> {
                try {
                    String banks = enterBank.getText();

                    String pastmonth1 = spendinginfo.getText();


                    String food1 = foodinfo.getText();


                    String travel1 = travelinfo.getText();


                    String utilities1 = utilitiesinfo.getText();


                    String rent1 = rentinfo.getText();

                    String misc1 = miscellaneousinfo.getText();


                    String miscellaneous1 = miscellaneousinfo.getText();
                    Map<String, String> month_ = new HashMap<String, String>();
                    month_.put("banks",banks);
                    month_.put("Total",pastmonth1);
                    month_.put("Food",food1);
                    month_.put("Travel",travel1);
                    month_.put("Utilities",utilities1);
                    month_.put("Rent",rent1);
                    month_.put("Misc",misc1);

                    String monthname  = whichmonth.getText();

                    monthdetails.put( monthname,month_);
                    AfterFdetailscreen(firstStage,monthdetails,pdetails,true);

                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            });
        }

        Button cancel = new Button ("Cancel");

        cancel.setOnAction(e -> {
            try {
                newuser(firstStage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        VBox v1 =  new VBox(25,h0,h1,h2,h3,h4,h5,h6,h7,confirm,cancel);
        v1.setAlignment(Pos.TOP_LEFT);
        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        Scene scene1 = new Scene(v1, 1000,1000);
        firstStage.setScene(scene1);
        firstStage.show();

    }









    //-------------------------------------------------------------------------------------------------------------
    static void AfterFdetailscreen(Stage firststage,Map<String,Map<String,String>> check,Boolean pdetails,Boolean fdetails) throws Exception {


        Button personaldetails;
        Button financialdetails ;
        if ( pdetails  == true) {
            personaldetails = new Button("Change Personal Details");
        }
        else {
            personaldetails = new Button("Add Personal Details");
        }
        if (fdetails == true) {
            financialdetails = new Button("Change Financial Details");
        }
        else {
            financialdetails = new Button("Add Financial Details");
        }
        Button Viewstats = new Button("View Stats");
        Button exit = new Button("Exit");

        VBox v1 = new VBox (50,personaldetails,financialdetails,Viewstats,exit);


        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));

        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();
        exit.setOnAction(f -> Platform.exit());

        Viewstats.setOnAction(e -> {
            try {
                viewstats(firststage);

            } catch (Exception e1) {

                e1.printStackTrace();
            }
        });
        personaldetails.setOnAction(e -> {
            try {

                Pdetailscreen(firststage,pdetails,fdetails);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        financialdetails.setOnAction(e -> {
            try {

                financialDetailsScreen(firststage,pdetails,fdetails,months,0);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }



    static void viewstats(Stage firststage) {

        Text text = new Text();


        text.setText("Select the type of stat ");

        ObservableList<String> options =
                FXCollections.observableArrayList(
                        "Bar graph",
                        "Pie Charts",
                        "Standout Stats"
                );

        final ComboBox comboBox = new ComboBox(options);
        Button confirm = new Button ("Confirm");



        confirm.setOnAction(e -> {
            try {
                System.out.println("ssssssssss");
                String check  = (String) comboBox.getValue();


                if (check == "Bar graph") {
                    Bargraph(firststage);
                }
                if (check == "Pie Charts") {
                    piechart(firststage);
                }
                if (check ==  "Standout Stats") {
                    standoutStats(firststage);
                }

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });


        VBox v1 =  new VBox(25,text, comboBox,confirm);
        v1.setAlignment(Pos.TOP_LEFT);
        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        v1.setAlignment(Pos.TOP_CENTER);
        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();


    }
    static void standoutStats(Stage firststage){


        double highest = 0;
        double lowest = 0;
        double count1 = 0;
        double count2 = 0;
        ArrayList<String> sections = new ArrayList<String>();
        ArrayList<String> associatedMonth = new ArrayList<String>();
        ArrayList<Number> highLow = new ArrayList<Number>();

        for(Entry<String,Map<String,String>> entry3: monthdetails.entrySet()){
            Map<String,String> checking = new HashMap<String,String>();
            checking = entry3.getValue();
            //checking.remove("banks");

            for(Map.Entry<String,String> entry4 : checking.entrySet()) {
                System.out.println("Key : " + entry4.getKey() + " Value : " + entry4.getValue());
                int s = Integer.parseInt(checking.get("Total"));
                System.out.println(s);
                highLow.add(s);
            }
        }

        for(Entry<String,Map<String,String>> entry: monthdetails.entrySet()){
            Map<String,String> temp = new HashMap<String,String>();
            temp = entry.getValue();
            temp.remove("banks");
            temp.remove("Total");
            //for(Map.Entry<String,String> entry2 : temp.entrySet()) {
            //System.out.println("Key : " + entry2.getKey() + " Value : " + entry2.getValue());
            //}
            String x = temp.entrySet().stream().max((entry1, entry2) -> Integer.parseInt(entry1.getValue()) > Integer.parseInt(entry2.getValue()) ? 1 : -1).get().getKey();
            //String x = Collections.max(temp.entrySet(), (entry1, entry2) -> Integer.parseInt(entry1.getValue()) > Integer.parseInt(entry2.getValue()) ).getKey();
            sections.add(x);
            associatedMonth.add(entry.getKey());
            System.out.println("In month " + entry.getKey() + x + " is the highest section spent on for this month");
        }

        Font f = Font.font("Verdana", FontWeight.BOLD, FontPosture.ITALIC,25);
        VBox v1 = new VBox();
        Text title1 = new Text("Top spent sections by month");
        title1.setFont(f);
        title1.setFill(Color.YELLOWGREEN);


        if (associatedMonth.size() == 1){
            Label month1 = new Label();
            Label section1 = new Label();

            month1.setText(associatedMonth.get(0));
            section1.setText(sections.get(0));

            month1.setFont(new Font("Verdana",18));
            section1.setFont((new Font("Verdana",18)));


            HBox h1 = new HBox(25,month1,section1);

            v1 = new VBox (25,title1,h1);

        }
        else if(associatedMonth.size() == 2){
            Label month1 = new Label();
            Label month2 = new Label();
            Label section1 = new Label();
            Label section2 = new Label();

            month1.setText(associatedMonth.get(0) + ": ");
            section1.setText(sections.get(0));
            month2.setText(associatedMonth.get(1) + ": ");
            section2.setText((sections.get(1)));

            month1.setFont(new Font("Verdana",18));
            section1.setFont((new Font("Verdana",18)));
            month2.setFont(new Font("Verdana",18));
            section2.setFont((new Font("Verdana",18)));

            HBox h1 = new HBox(25,month1,section1);
            HBox h2 = new HBox(25,month2,section2);

            v1 = new VBox (25,title1,h1,h2);
        }
        else{
            Label month1 = new Label();
            Label month2 = new Label();
            Label month3 = new Label();
            Label month4 = new Label();
            Label month5 = new Label();
            Label month6 = new Label();
            Label section1 = new Label();
            Label section2 = new Label();
            Label section3 = new Label();
            Label section4 = new Label();
            Label section5 = new Label();
            Label section6 = new Label();

            month1.setText(associatedMonth.get(0) + ": ");
            section1.setText(sections.get(0));
            month2.setText(associatedMonth.get(1) + ": ");
            section2.setText((sections.get(1)));
            month3.setText(associatedMonth.get(2) + ": ");
            section3.setText((sections.get(2)));
            month4.setText(associatedMonth.get(3) + ": ");
            section4.setText((sections.get(3)));
            month5.setText(associatedMonth.get(4) + ": ");
            section5.setText((sections.get(4)));
            month6.setText(associatedMonth.get(5) + ": ");
            section6.setText((sections.get(5)));

            month1.setFont(new Font("Verdana",18));
            section1.setFont((new Font("Verdana",18)));
            month2.setFont(new Font("Verdana",18));
            section2.setFont((new Font("Verdana",18)));
            month3.setFont(new Font("Verdana",18));
            section3.setFont((new Font("Verdana",18)));
            month4.setFont(new Font("Verdana",18));
            section4.setFont((new Font("Verdana",18)));
            month5.setFont(new Font("Verdana",18));
            section5.setFont((new Font("Verdana",18)));
            month6.setFont(new Font("Verdana",18));
            section6.setFont((new Font("Verdana",18)));

            HBox h1 = new HBox(25,month1,section1);
            HBox h2 = new HBox(25,month2,section2);
            HBox h3 = new HBox(25,month3,section3);
            HBox h4 = new HBox(25,month4,section4);
            HBox h5 = new HBox(25,month5,section5);
            HBox h6 = new HBox(25,month6,section6);

            v1 = new VBox (25,title1,h1,h2,h3,h4,h5,h6);
        }
        //
        //Back button not working correctly (test this by using after selecting standout stats: it will return null )
        //
        Button back = new Button("Back");
        back.setOnAction(e -> {
            try {
                viewstats(firststage);

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        back.setAlignment(Pos.TOP_RIGHT);
        HBox hStats = new HBox(20,v1,back);

        hStats.setAlignment(Pos.TOP_LEFT);
        hStats.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));

        Scene scene1 = new Scene(hStats, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();
    }

    static void piechart(Stage firststage) {

        ArrayList< String> monthnames = new ArrayList< String>(monthdetails.size());
        ArrayList< PieChart > piecharts = new ArrayList< PieChart>(monthdetails.size());
        for (Entry<String, Map<String, String>> entry : monthdetails.entrySet()) {


            monthnames.add(entry.getKey());
            Map<String,String> getchart = entry.getValue();


            String bankvalue = getchart.get("banks");
            Number foodval = Integer.parseInt(getchart.get("Food"));
            Number travelval = Integer.parseInt(getchart.get("Travel"));
            Number Utilitiesval = Integer.parseInt(getchart.get("Utilities"));
            Number rentval = Integer.parseInt(getchart.get("Rent"));
            Number misc = Integer.parseInt(getchart.get("Misc"));
            Number pastmonthtotal = Integer.parseInt(getchart.get("Total"));



            ObservableList<PieChart.Data> pieChartData =
                    FXCollections.observableArrayList(
                            new PieChart.Data("Food",foodval.doubleValue()),
                            new PieChart.Data("Travel",travelval.doubleValue()),
                            new PieChart.Data("Utilities",Utilitiesval.doubleValue()),
                            new PieChart.Data("Rent",rentval.doubleValue()),
                            new PieChart.Data("Miscellaneous",misc.doubleValue()));
            final PieChart pieChart = new PieChart(pieChartData);
            pieChart.setTitle("Monthly Spending Distribution of " + "$" +pastmonthtotal.doubleValue());
            pieChartData.forEach(data->
                    data.nameProperty().bind(
                            Bindings.concat(
                                    data.getName(), " amount: ", Math.round((data.pieValueProperty().doubleValue()/1000)*100) , "%"
                            )
                    ));
            piecharts.add(pieChart);


        }
        System.out.println(monthdetails.size());
        Button back = new Button("Back");
        back.setOnAction(e -> {
            try {
                viewstats(firststage);

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        VBox v1;
        if (monthdetails.size() == 2) {
            v1 =  new VBox(25,piecharts.get(0),piecharts.get(1),back);
        }
        else if (monthdetails.size() == 1) {
            v1 =  new VBox(25,piecharts.get(0),back);
        }
        else  {
            v1 =  new VBox(5,piecharts.get(0),piecharts.get(1),piecharts.get(2),piecharts.get(3),piecharts.get(4),piecharts.get(5),back);
        }
        HBox h1 = new HBox (20,v1,back);

        h1.setAlignment(Pos.TOP_LEFT);
        h1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));

        Scene scene1 = new Scene(h1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();



    }


    static void Bargraph(Stage firststage) {
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setCategories(FXCollections.<String>
                observableArrayList(Arrays.asList("Food", "Travel", "Utilities", "Rent","Misc")));
        xAxis.setLabel("category");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("score");
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Spending Comparison between each month ");

        ArrayList< String> monthnames = new ArrayList< String>(monthdetails.size());
        ArrayList< XYChart.Series<String, Number> > series = new ArrayList< XYChart.Series<String, Number>>(monthdetails.size());
        for (Entry<String, Map<String, String>> entry : monthdetails.entrySet()) {


            Map<String,String> getchart = entry.getValue();


            String bankvalue = getchart.get("banks");
            Number foodval = Integer.parseInt(getchart.get("Food"));
            Number travelval = Integer.parseInt(getchart.get("Travel"));
            Number Utilitiesval = Integer.parseInt(getchart.get("Utilities"));
            Number rentval = Integer.parseInt(getchart.get("Rent"));
            Number misc = Integer.parseInt(getchart.get("Misc"));
            Number pastmonthtotal = Integer.parseInt(getchart.get("Total"));

            XYChart.Series<String, Number> series1 = new XYChart.Series<>();

            series1.setName(entry.getKey());
            series1.getData().add(new XYChart.Data<>("Food", foodval));
            series1.getData().add(new XYChart.Data<>("Travel", travelval));
            series1.getData().add(new XYChart.Data<>("Utilities", Utilitiesval));
            series1.getData().add(new XYChart.Data<>("Rent", rentval));
            series1.getData().add(new XYChart.Data<>("Misc", misc));

            series.add(series1);
        }
        if (monthdetails.size() == 1) {
            barChart.getData().addAll(series.get(0));
        }
        if (monthdetails.size() == 2) {
            barChart.getData().addAll(series.get(0),series.get(1));
        }
        if (monthdetails.size() == 6) {
            barChart.getData().addAll(series.get(0),series.get(1),series.get(2),series.get(3),series.get(4),series.get(5));
        }
        Button back = new Button("Back");
        back.setOnAction(e -> {
            try {
                viewstats(firststage);

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });


        VBox v1 =  new VBox(25,barChart,back);
        v1.setAlignment(Pos.TOP_LEFT);
        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));
        v1.setAlignment(Pos.TOP_CENTER);
        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.show();

    }
//-------------------------------------------------------------------------------------------------------------

    static void AfterPdetailscreen(Stage firststage,String name , String phno1, String Email1,LocalDate DOB1,Boolean pdetails,Boolean fdetails) throws Exception {
        Button personaldetails;
        Button financialdetails ;

        name1   = name;
        no = phno1;
        email = Email1;
        dob = DOB1;

        if ( pdetails  == true) {
            personaldetails = new Button("Change Personal Details");
        }
        else {
            personaldetails = new Button("Add Personal Details");
        }
        if (fdetails == true) {
            financialdetails = new Button("Change Financial Details");
        }
        else {
            financialdetails = new Button("Add Financial Details");
        }
        Button Viewstats = new Button("View Stats");
        if(fdetails == false) {
            Viewstats.setDisable(true);
        }
        Button exit = new Button("Exit");
        //Viewstats.setDisabled(true);
        VBox v1 = new VBox (50,personaldetails,financialdetails,Viewstats,exit);

        v1.setBackground(new Background(
                new BackgroundImage(
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                )));

        Scene scene1 = new Scene(v1, 1000,1000);
        firststage.setScene(scene1);
        firststage.setTitle(" Money man Application :" + name1);
        firststage.show();
        exit.setOnAction(f -> Platform.exit());
        personaldetails.setOnAction(e -> {
            try {

                Pdetailscreen(firststage,pdetails,fdetails);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        financialdetails.setOnAction(e -> {
            try {
                //Change this: We do not prompt user for number of months to fill out when we fill out personal details first (test this by adding personal info first then financial details)
                financialDetailsScreen(firststage,pdetails,fdetails,months,0);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
    }



    //-----------------------------------------------------------------------------------------------------------------------


    static void setfirstscreen(Stage firststage) throws Exception {
        v = new VBox(20);
        Button b1 = new Button(" Menu");
        Button backbutton = new Button("Back");
        firststage.setTitle(" Money man Application ");
        Button back = new Button("Back");
//---------------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------------

        EventHandler<ActionEvent> DisplayRules = new EventHandler<ActionEvent>() { // event handler for display rules button
            public void handle(ActionEvent e) {
                Label t1 = new Label ("1) User will be able to see their area of spendings ");
                Label t2 = new Label ( "2) Application will help user to manage their spending ");
                Label t3 = new Label ("3) AI will automatically give savings tips to user upon request");
                Label t4 = new Label  ("4) Statistics of monthly finance flow ");
                VBox v1 = new VBox(25,t1,t2,t3,t4,backbutton);

                v1.setBackground(new Background(
                        new BackgroundImage(
                                new Image(imgADR),
                                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )));
                Scene scene1 = new Scene(v1, 1000,1000);
                firststage.setScene(scene1);
                firststage.show();

            }

        };
//---------------------------------------------------------------------------------------------------------------------------
        EventHandler<ActionEvent> Howitworks = new EventHandler<ActionEvent>() { // event handler for display odds button
            public void handle(ActionEvent e) {
                Label t1 = new Label ("New user need to fill in their Earnings and spendings");
                Label t2 = new Label (" Categories to spending areas will be provided by APP");
                Label t3 = new Label ("User can select a month from last one year and fill in money flow ");
                VBox v1 = new VBox(25,t1,t2,t3,backbutton);

                v1.setBackground(new Background(
                        new BackgroundImage(
                                new Image(imgADR),
                                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )));
                Scene scene1 = new Scene(v1, 1000,1000);

                firststage.setScene(scene1);
                firststage.show();
            }
        };

//---------------------------------------------------------------------------------------------------------------------------
        EventHandler<ActionEvent> NewUser = new EventHandler<ActionEvent> () {


            public void handle(ActionEvent event) {
                Button personaldetails = new Button("Add Personal Details");
                Button financialdetails = new Button("Add Financial Details");
                Button Viewstats = new Button("View Stats");
                Viewstats.setDisable(true);
                VBox v1 = new VBox (50,personaldetails,financialdetails,Viewstats,backbutton);

                v1.setBackground(new Background(
                        new BackgroundImage(
                                new Image(imgADR),
                                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )));
                personaldetails.setOnAction(e -> {
                    try {

                        Pdetailscreen(firststage,false,false);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                });
                financialdetails.setOnAction(e -> {
                    try {

                        Fdetailsoptions(firststage,false,false);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                });
                Scene scene1 = new Scene(v1, 1000,1000);
                firststage.setScene(scene1);
                firststage.show();

            }

        };




//---------------------------------------------------------------------------------------------------------------------------
        EventHandler<ActionEvent> Menu  = new EventHandler<ActionEvent>() { // basic menu and when start menu is clicked new menu with "New Look" option is unlocked
            public void handle(ActionEvent e) {

                //********************************************************************
                //ADDING MENU BAR
                Menu m = new Menu("Themes");

                // create menuitems
                MenuItem m1 = new MenuItem("Theme 1");
                MenuItem m2 = new MenuItem("Theme 2");
                MenuItem m3 = new MenuItem("Theme 3");



                // add menu items to menu
                m.getItems().add(m1);
                m.getItems().add(m2);
                m.getItems().add(m3);

                // create a menubar
                MenuBar mb = new MenuBar();

                // add menu to menubar
                mb.getMenus().add(m);


                Button b2 = new Button("Display Basic Uses ");
                Button b3 = new Button("How it works");
                Button b5 = new Button("New User");
                Button b4 = new Button("Exit ");
                //**************************************************************
                // LOGIN PAGE CODE STARTS FROM HERE
                Button login = new Button ("Login");
                // Image i = new Image(new File("giphy.gif").toURI().toString());
                //  ImageView iw = new ImageView(i);
                //Label b = new Label("", iw);
                //b.setAlignment(Pos.CENTER_RIGHT);
                Button backFromLogin = new Button ("Back");
                Button StoreDb = new Button("Submit");
                final String[] emailDB = {""};
                String nameDb = "";
                final Label[] l2 = new Label[1];
                final TextField[] emailField = new TextField[1];
                final Label[] l3 = new Label[1];
                final TextField[] namelField = new TextField[1];
                m1.setOnAction(new EventHandler < ActionEvent > () {
                    public void handle(ActionEvent a) {
                        themeSelector = 'a';
                        imgADR = "https://www.softpaz.com/themescreenshots/light-blue/12.png";
                        VBox v1 = new VBox (100, mb, b2,b3,b5,b4, login);
                        HBox h = new HBox(100,v1);
                        h.setBackground(new Background(
                        new BackgroundImage(
                                new Image(imgADR),
//                                new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7MmfKPT_pzXXmBiGFXRDoFnYUgpFBmTo28A&usqp=CAU"),
                                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )));

                        Scene scene1 = new Scene(h, 1000,1000);
                        firststage.setScene(scene1);
                        firststage.show();

                    }
                });
                m2.setOnAction(new EventHandler < ActionEvent > () {
                    public void handle(ActionEvent a) {
                        themeSelector = 'a';
                        imgADR = "https://st.depositphotos.com/1084193/1999/v/950/depositphotos_19997073-stock-illustration-great-light-futuristic-computer-technology.jpg";
                        VBox v1 = new VBox (100, mb, b2,b3,b5,b4, login);
                        HBox h = new HBox(100,v1);
                        h.setBackground(new Background(
                                new BackgroundImage(
                                        new Image(imgADR),
//                                new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7MmfKPT_pzXXmBiGFXRDoFnYUgpFBmTo28A&usqp=CAU"),
                                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                                )));

                        Scene scene1 = new Scene(h, 1000,1000);
                        firststage.setScene(scene1);
                        firststage.show();

                    }
                });
                m3.setOnAction(new EventHandler < ActionEvent > () {
                    public void handle(ActionEvent a) {
                        themeSelector = 'a';
                        imgADR = "https://static.vecteezy.com/system/resources/thumbnails/002/017/939/original/cosmic-galaxy-with-nebula-free-video.jpg";
                        VBox v1 = new VBox (100, mb, b2,b3,b5,b4, login);
                        HBox h = new HBox(100,v1);
                        h.setBackground(new Background(
                                new BackgroundImage(
                                        new Image(imgADR),
//                                new Image("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7MmfKPT_pzXXmBiGFXRDoFnYUgpFBmTo28A&usqp=CAU"),
                                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                                )));

                        Scene scene1 = new Scene(h, 1000,1000);
                        firststage.setScene(scene1);
                        firststage.show();

                    }
                });
                login.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        System.out.println("login was clicked");


//


                        Label l1 = new Label("Enter your name: ");
                        // create a textfield
                        TextField b = new TextField();
                        HBox myBox = new HBox(50, l1, b  );

                        l2[0] = new Label("Enter your email: ");
                        // create a textfield
                        emailField[0] = new TextField();
                        HBox myBox2 = new HBox(50, l2[0], emailField[0]);

                        l3[0] = new Label("Enter your name: ");
                        // create a textfield
                        namelField[0] = new TextField();
                        HBox myBox3 = new HBox(50, l3[0], namelField[0]);

                        Label l4 = new Label("Enter your password : ");
                        // create a textfield

                        PasswordField passField = new PasswordField();
                        HBox myBox4 = new HBox(50, l4, passField  );





                        VBox mainBox = new VBox(50, myBox, myBox2, myBox3, myBox4, backFromLogin, StoreDb );
                        mainBox.setBackground(new Background(
                                new BackgroundImage(
                                        new Image(imgADR),
//                                        new Image("https://autovista24.autovistagroup.com/wp-content/uploads/sites/5/2022/09/what-is-1024x632.jpg"),
                                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                                )));



                        Scene loginScene = new Scene(mainBox, 1000,1000);
                        firststage.setScene(loginScene);
                        firststage.show();
                    }
                });



                VBox v1 = new VBox (100, mb, b2,b3,b5,b4, login);
                HBox h = new HBox(100,v1);
                h.setBackground(new Background(
                        new BackgroundImage(
//                                new Image("https://autovista24.autovistagroup.com/wp-content/uploads/sites/5/2022/09/what-is-1024x632.jpg"),
                                new Image(imgADR),
                                BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                        )));
                Scene scene1 = new Scene(h, 1000,1000);


                backFromLogin.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        System.out.println("login back was clicked");
                        VBox v1 = new VBox (100, mb, b2,b3,b5,b4, login);
                        HBox h = new HBox(100,v1);
                        h.setBackground(new Background(
                                new BackgroundImage(
//                                new Image("https://autovista24.autovistagroup.com/wp-content/uploads/sites/5/2022/09/what-is-1024x632.jpg"),
                                        new Image(imgADR),
                                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                                )));
                        Scene scene1 = new Scene(h, 1000,1000);
                        firststage.setScene(scene1);
                        firststage.show();
                    }
                });

                StoreDb.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        try {
                            FileWriter myWriter = new FileWriter("C:\\OLD LAPTOP STUFF\\uic\\SP21\\CS 342\\PROJECTS\\PROJECT2\\JavaFXTemplate\\src\\main\\java\\com\\example\\javafxtemplate\\filename.txt", true);
                            BufferedWriter bw = new BufferedWriter(myWriter);

                            emailDB[0] = emailField[0].getText();
                            bw.write(emailDB[0]);
                            bw.newLine();
                            bw.close();
                            System.out.println("Successfully wrote to the file.");
                        } catch (IOException e) {
                            System.out.println("An error occurred.");
                            e.printStackTrace();
                        }


                    }
                });
                firststage.setScene(scene1);
                firststage.show();
                b2.setOnAction(DisplayRules);
                b3.setOnAction(Howitworks);
                b5.setOnAction(NewUser);
                b4.setOnAction(f -> Platform.exit());

            }


        };
//---------------------------------------------------------------------------------------------------------------------------
        backbutton.setOnAction(Menu);
        back.setOnAction(NewUser);
        b1.setOnAction(Menu);
        Label t1 = new Label("                                    MoneyMan App");
        VBox v1 = new VBox (29,b1);
        GridPane rootGrid = new GridPane();
        rootGrid.setAlignment(Pos.CENTER_LEFT);
        rootGrid.setPadding(new Insets(16));
        rootGrid.setHgap(16);
        rootGrid.setVgap(8);

        Image i = new Image(imgADR);
        ImageView iw = new ImageView(i);
        Label b = new Label("WELCOME TO MONEY MAN", iw);
        b. setFont(new Font("Arial", 30));
        rootGrid.add(v1, 0, 2);
        b.setAlignment(Pos.TOP_CENTER);
        VBox Title = new VBox(100,b,rootGrid);

        Title.setBackground(new Background(
                new BackgroundImage(
//                        new Image("https://autovista24.autovistagroup.com/wp-content/uploads/sites/5/2022/09/what-is-1024x632.jpg"),
                        new Image(imgADR),
                        BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT,
                        new BackgroundPosition(Side.LEFT, 0, true, Side.BOTTOM, 0, true),
                        new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true)
                ))

        );

        Scene scene = new Scene(Title, 1000, 1000);
        firststage.setScene(scene);
        firststage.setTitle("MoneyMan App");
        firststage.setScene(scene);
        firststage.show();
    }



    @Override
    public void start(Stage primaryStage) throws Exception {
        setfirstscreen(primaryStage);

    }

}

