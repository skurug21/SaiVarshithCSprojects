

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

import java.util.ArrayList;

import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventTarget;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {
	public static PauseTransition p1 = new PauseTransition(Duration.seconds(1));  // for pause transiiton
	public static VBox v ; // vbox for fscreen which is used to show lottery selected numbers 
	
	public static double winnings = 0 ; // total winnings
	public static int spot = 0 ; // number of spots selected 
	 public static int spotsetter = 0 ;  // need second one because I used the first one to count number of boxes selected on grid 
	 public static int spotsetter2 = 0 ; // for looping and displaying of lottery selcted vals
	 public static int drawings = 0 ;  // number of drawings 
	 public static int betamount1 = 0 ;  // amount the person want to bet
	 public static Boolean selection = false ;  // this is for random selection
	public static ArrayList<Integer> selectedvals = new ArrayList<>();  // user selected vals or random vals
	public static ArrayList<Integer> Lotteryvals = new ArrayList<>();  // lottery pickings
	 public static String s ;
	 
//-------------------------------------------------------------------------------------------------------------	 
	public static void main(String[] args) {
		launch(args);
	}
//-------------------------------------------------------------------------------------------------------------	 	
	
			
	//-----------------------------------------------------------------------------------------------------------------------	
	
	
	static void setfirstscreen(Stage firststage) throws Exception {
    // since it is the first screen setting all the values to zero again
		  v = new VBox(20);
          winnings = 0 ;
		  spot = 0 ;
          spotsetter = 0 ;
	      spotsetter2 = 0 ;
	      drawings = 0 ;
		  betamount1 = 0 ;
	      selection = false ;
	     selectedvals.clear();
		 Lotteryvals.clear();
	      s = "" ;
		Button b1 = new Button(" Menu");
		Button backbutton = new Button("Back");
		Label t1 = new Label("                                    MoneyMan App");
		firststage.setTitle(" Money man Application ");
		
		EventHandler<ActionEvent> DisplayRules = new EventHandler<ActionEvent>() { // event handler for display rules button
 			public void handle(ActionEvent e) {
				Label t1 = new Label ("1) User will be able to see their area of spendings ");
				Label t2 = new Label ( "2) Application will help user to manage their spending ");
				Label t3 = new Label ("3) AI will automatically give savings tips to user upon request");
			    Label t4 = new Label  ("4) Statistics of monthly finance flow ");
			   // Label t5 = new Label  (" 5) The amount of numbers drawn and matched that the players are allowed to wager on will differ from casino to casino and state lottery to state lottery.");
				Scene scene1 = new Scene(new VBox(25,t1,t2,t3,t4,backbutton), 500,500);
				firststage.setScene(scene1);
				firststage.show();
				
			}
			
			};
			EventHandler<ActionEvent> Howitworks = new EventHandler<ActionEvent>() { // event handler for display odds button
				public void handle(ActionEvent e) {
					Label t1 = new Label ("New user need to fill in their Earnings and spendings");
					Label t2 = new Label (" Categories to spending areas will be provided by APP");
					Label t3 = new Label ("User can select a month from last one year and fill in money flow ");
					
					Scene scene1 = new Scene(new VBox(25,t1,t2,t3,backbutton), 500,500);
					firststage.setScene(scene1);
					firststage.show();
				}
				};
			
			
					
				
				
					
				EventHandler<ActionEvent> GameMenu  = new EventHandler<ActionEvent>() { // event handler for game menu without new look
					public void handle(ActionEvent e) {
						Button b2 = new Button("Display Rules");
						Button b3 = new Button("Display Odds");
						Button b4 = new Button("Exit Game");
						Button b5 = new Button("Start Game");
					//	Button b6 = new Button("New Look");
						VBox v1 = new VBox(25,b2,b3,b4,b5);
						//b6.setOnAction(GameMenu1);
						Scene scene1 = new Scene(v1, 500,500);
						firststage.setScene(scene1);
						firststage.show();
						b2.setOnAction(DisplayRules);
						b3.setOnAction(Howitworks);
						b4.setOnAction(f -> Platform.exit());
						//b5.setOnAction(setpane);
					}
				};
				
				
		EventHandler<ActionEvent> Menu  = new EventHandler<ActionEvent>() { // basic menu and when start menu is clicked new menu with "New Look" option is unlocked
			public void handle(ActionEvent e) {
				Button b2 = new Button("Display Basic Uses ");
				Button b3 = new Button("How it works");
				Button b5 = new Button("New User");
				Button b4 = new Button("Exit ");
				
				Scene scene1 = new Scene(new VBox(25,b2,b3,b5,b4), 500,500);
				firststage.setScene(scene1);
				firststage.show();
				b2.setOnAction(DisplayRules);
				b3.setOnAction(Howitworks);
				b4.setOnAction(f -> Platform.exit());
				b5.setOnAction(GameMenu);

			}
		};
		 InputStream stream = new FileInputStream("baby_elephant_wildlife_reserve_elephant_south_africa.jpg");
	      Image image = new Image(stream);
	      //Creating the image view
	      ImageView imageView = new ImageView();
	      //Setting image to the image view
	      imageView.setImage(image);
	      //Setting the image view parameters
	      imageView.setX(10);
	      imageView.setY(10);
	      imageView.setFitWidth(575);
	      imageView.setPreserveRatio(true);
	      //Setting the Scene object
	      Group root = new Group(imageView);
	     // Scene scene = new Scene(root, 595, 370);
		
		backbutton.setOnAction(Menu);
		b1.setOnAction(Menu);
		VBox v1 = new VBox (29,t1,b1,root);
		
		Scene scene = new Scene(v1, 500,500);
		
		scene.setFill(Color.web("#81c483"));
		firststage.setScene(scene);
		firststage.show();
	}
	
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		setfirstscreen(primaryStage);
		
	}

}
