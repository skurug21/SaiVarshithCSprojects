import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;



public class Client extends Thread{

	
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	private Consumer<Serializable> callback;
	private Consumer<Serializable> callback2;
	private Consumer<Serializable> callback3;
	ArrayList<Info> clients2 = new ArrayList<Info>();
	Client(Consumer<Serializable> call,Consumer<Serializable> call2,Consumer<Serializable> call3){
	
		callback = call;  // for messages
		callback2 = call2;  // for players list display
		callback3 = call3;  // show selection of players during group message
	}
	
	public void run() {
		
		try {
		socketClient= new Socket("127.0.0.1",5555);
	    out = new ObjectOutputStream(socketClient.getOutputStream());
	    in = new ObjectInputStream(socketClient.getInputStream());
	    socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {}
		
		while(true) {
			
			try {
			Info message = (Info) in.readObject();
			
			if (message.forlist2 == 0) {  // if it is a message
			if (message.forsendone == true) { // if it is for one person
				System.out.println(" Inside client of for send one true");
				callback.accept("Personal Message from Client#" + message.fromID + ": " + message.message );
			}
			else if (message.forsendgroup == true) {  // if it is for a group
				System.out.println(" Inside client of for send group true");
				callback.accept("Group Message from Client#" + message.fromID + ": " + message.message );
			}
			else { // send all message
			callback.accept(message.message);
			}
			}
			else { // this is not a message and info about players
				callback2.accept(message.message);
				if (message.remove == false) {  // info about player leaving
			clients2.add(message);
			}
				else if (message.remove == true){  // info about player adding
					clients2.remove(message.removeno);
				}
			}
			}
			catch(Exception e) {}
		}
	
    }
	
	public synchronized void send(String data) {  // synchronized 
		Info n = new Info();
		n.message = data;
		try {
			out.writeObject(n);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Info> getclients() {  // to get the details of all the clients connected to the server in the form of arraylist
		for (int i = 0; i < clients2.size();i++) {
			Info s = clients2.get(i);
			
		}
   return clients2;

}
    public synchronized void sendone(String value,String message) {  // send details of the client to send the personal message to the server
    	int val = Integer.parseInt(value);
    	Info sendonedata = new Info();
    	sendonedata.forsendone = true;
    	sendonedata.IdOne = val;
    	sendonedata.message = message;
    	
    	try {
			out.writeObject(sendonedata);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    }
    
    public void sendlistviewgroup(String n) {  // to show on the listview that a person is selected in the group chat
    	callback3.accept("Client# " + n + " selected into the group");
    }
    public synchronized void sendgroup(ArrayList<Integer> IDs,String message) { // send server the details of the group memebers slected
    	for (int i = 0; i < IDs.size();i++) {
    		int ID = IDs.get(i);
    		Info send = new Info();
    		send.forsendgroup = true;
    		send.IdOne = ID;
    		send.message = message;
    		try {
    			out.writeObject(send);
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
    	}
    }
	
}

class Info implements 
Serializable{
	
	private static final long serialVersionUID = 1L;
	int ClientID = 0;
	int select = 0;
	String message = "";
	int forlist2 = 0;
	int removeno = 0;
	boolean remove = false;
	boolean checklist = false;
	boolean getarraylist = false ;
	boolean forsendone = false;
	boolean forsendgroup = false;
	int IdOne = 0;
	int fromID = 0;
}
