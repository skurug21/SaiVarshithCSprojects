import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;


import javafx.application.Platform;
import javafx.scene.control.ListView;


public class Server{

	int count = 1;	
	int count1 = 0;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	ArrayList<Info> clients1 = new ArrayList<Info>(); // arraylist for the serializable data of clients
	
	Server(Consumer<Serializable> call){
	
		callback = call;
		server = new TheServer();
		server.start();
	}
	
	
	public class TheServer extends Thread{
		
		public void run() {
		
			try(ServerSocket mysocket = new ServerSocket(5555);){
		    System.out.println("Server is waiting for a client!");
		  
			
		    while(true) {
		
				ClientThread c = new ClientThread(mysocket.accept(), count,count1);
				callback.accept("client has connected to server: " + "client #" + count);
				clients.add(c);
				c.start();
				
				count++; // for the ID number 
				count1++;  // for the position in the arrayList
			    }
			}//end of try
				catch(Exception e) {
					callback.accept("Server socket did not launch");
				}
			}//end of while
		}
	

		class ClientThread extends Thread{
			
		
			Socket connection;
			int count;
			ObjectInputStream in;
			ObjectOutputStream out;
			int count2;
			Info newclient = new Info();
			ClientThread(Socket s, int count,int count2){
				this.connection = s;
				this.count = count;	
				this.count2 = count2;
				
				newclient.ClientID = count; //  new clienthread , add it to the arralist of info as well
				clients1.add(newclient);
			}
			
			
			public void updateClients(Info message) {  // send the details of newly joined client to the previously present clients 
				System.out.println("1");
				for(int i = 0; i < count2; i++) {
					ClientThread t = clients.get(i);
					System.out.println("sss");
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			}
			public void updateClients2(int count) { // send the details of all the clients to the newly joined client
				System.out.println("2");
					ClientThread t = clients.get(count);
					for(int a = 0; a < clients1.size(); a++) {
						Info message = clients1.get(a);
						
						message.forlist2 = 1;
						message.message = "new client on server: client #"+message.ClientID;
						
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
						}
						
				}
		
         public void updateClients3(Info message) { // send the message to all the clients 
				
				for(int i = 0; i < clients.size(); i++) {
					ClientThread t = clients.get(i);
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			}

         public void updateClients4(Info message,int fromID) { // used to send the message to a group or just one person
        	 int pos = 0;
				  for (int i = 0 ; i < clients1.size();i++) {
					  Info check = clients1.get(i);
					  if (message.IdOne ==check.ClientID ) {
						  pos = i;
						  break;
					  }
				  }
					ClientThread t = clients.get(pos);
					message.fromID = fromID;
					
					
					
					try {
					 t.out.writeObject(message);
					}
					catch(Exception e) {}
				}
			

			public void run(){
					
				try {
					in = new ObjectInputStream(connection.getInputStream());
					out = new ObjectOutputStream(connection.getOutputStream());
					connection.setTcpNoDelay(true);	
				}
				catch(Exception e) {
					System.out.println("Streams not open");
				}
				newclient.forlist2 = 1;
				newclient.message = "new client on server: client #"+count;
				
					
				    if (count2 == 0) { // that means it is first client 
				    	updateClients2(count2);
				    }
				   else if ( count2 > 0){
					   
				    	updateClients(newclient); 
				    	updateClients2(count2);
				    }
				 while(true) {
					    try {
					    	Info data = (Info) in.readObject();
					        if (data.forsendone == false && data.forsendgroup == false) { // simple message to all
					        callback.accept("client: " + count + " sent: " + data.message);
					    	data.message = "client #"+count+" said: "+data.message;
					    	updateClients3(data);
					        }
					        else if (data.forsendone == true && data.forsendgroup== false) { // if it is for one person
					        	
					        	updateClients4(data,count);
					        }
					        else if (data.forsendgroup == true && data.forsendone == false) { // if it is for group
					        	updateClients4(data,count);
					        }
					    	
					    	}
					    catch(Exception e) {
					    	callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
					    	Info message1 = new Info();
							message1.forlist2 = 1;
							message1.remove = true; // so that clients can check and send appropriate message
							message1.removeno = count2;
							message1.message = "Client #"+count + " Left the chat";
					    	updateClients3(message1); // to let everyone know client left the chat
					    	clients.remove(this);
					    	clients1.remove(count2);
					    	count1--; // reduce count 
					    	break;
					    }
					}
				}//end of run
			
			
		}//end of client thread
}
		




	
	

	
